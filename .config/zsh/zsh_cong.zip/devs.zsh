# ============================================================================
# HOMEBREW
# ============================================================================
if [[ -f "/opt/homebrew/bin/brew" ]]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [[ -f "/usr/local/bin/brew" ]]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# ============================================================================
# SHELL TOOLS
# ============================================================================
command -v fzf     >/dev/null 2>&1 && eval "$(fzf --zsh)"
command -v zoxide  >/dev/null 2>&1 && eval "$(zoxide init --cmd cd zsh)"
command -v thefuck >/dev/null 2>&1 && eval "$(thefuck --alias)"

# ============================================================================
# NODE (NVM)
# ============================================================================
export NVM_DIR="$HOME/.nvm"
[[ -s "$NVM_DIR/nvm.sh" ]]          && source "$NVM_DIR/nvm.sh"
[[ -s "$NVM_DIR/bash_completion" ]] && source "$NVM_DIR/bash_completion"

# ============================================================================
# BUN
# ============================================================================
[[ -s "$HOME/.bun/_bun" ]] && source "$HOME/.bun/_bun"

# ============================================================================
# JETBRAINS
# ============================================================================
[[ -f "${HOME}/.jetbrains.vmoptions.sh" ]] && source "${HOME}/.jetbrains.vmoptions.sh"

# ============================================================================
# SDKMAN (must be last — appends to PATH at runtime)
# ============================================================================
export SDKMAN_DIR="$HOME/.sdkman"
[[ -s "$SDKMAN_DIR/bin/sdkman-init.sh" ]] && source "$SDKMAN_DIR/bin/sdkman-init.sh"

# ============================================================================
# SSH AGENT
# ============================================================================
[[ -z "$SSH_AUTH_SOCK" ]] && eval "$(ssh-agent -s)" >/dev/null
