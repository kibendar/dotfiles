# OMZ plugin list — loaded by oh-my-zsh.sh in .zshrc
# Rules: fzf-tab must be first, zsh-syntax-highlighting must be last
plugins=(
    fzf-tab
    git
    z
    docker
    fzf
    zsh-history-substring-search
    zsh-autosuggestions
    zsh-vi-mode
    zsh-syntax-highlighting
)

zplugin-update() {
    local dir
    for dir in "${ZSH_CUSTOM:-$ZSH/custom}/plugins"/*/; do
        [[ -d "$dir/.git" ]] || continue
        echo "Updating ${dir:t}..."
        git -C "$dir" pull --ff-only
    done
}
