# =========================================================
# File system
# =========================================================
alias ls='eza --icons=always --no-time --no-user --no-permissions'
alias ll='eza -lh --icons --git'
alias la='eza -lah --icons --git'
alias tree='eza --tree --icons'
compdef eza=ls

alias cat='bat'
alias grep='rg --color=auto'
alias diff='diff --color=auto'
alias df='df -h'
alias -- -='cd -'
alias rzsh="exec zsh"

# =========================================================
# Editor
# =========================================================
alias v='nvim'
alias vim='nvim'

# =========================================================
# Git
# =========================================================
alias g='git'
alias glog='PAGER="less -F -X" git log'
alias gadog='PAGER="less -F -X" git log --all --decorate --oneline --graph'
alias dotfiles='git --git-dir=$HOME/.dotfiles --work-tree=$HOME'
alias gcamend='git commit --amend -m'

# =========================================================
# Docker
# =========================================================
alias d='sudo docker'
alias dcu='sudo docker-compose up'
alias dcd='sudo docker-compose down'

# =========================================================
# Tmux
# =========================================================
alias t='tmux'
alias ta='tmux a -t'
alias ts='tmux new -s'
alias tk='tmux kill-ses -t'

# =========================================================
# Python
# =========================================================
alias python='python3.14'
alias p9='python3.9'

# =========================================================
# Shell utilities
# =========================================================
alias y='yazi'
alias ff='fastfetch'

alias h2d='printf "%d\n" 0x'
alias d2h='printf "%x\n"'
alias d2H='printf "%X\n"'

# =========================================================
# Claude
# =========================================================
 alias c="claude"
 alias cc="claude --continue"
 
# =========================================================
# Project shortcuts
# =========================================================
alias alp='python3 ~/PythonProj/PythonScripts/start_pro.py'
alias hub_log_1='minicom -o -D /dev/tty.usbserial-*20'
alias hub_log_2='minicom -o -D /dev/tty.usbserial-*30'

# =========================================================
# Video
# =========================================================
alias stream='mpv av://v4l2:/dev/video4 --fullscreen --demuxer-lavf-o=input_format=mjpeg,framerate=30 --profile=low-latency --untimed'
