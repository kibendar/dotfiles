# ============================================================================
# OH MY ZSH
# ============================================================================
export ZSH="$HOME/.oh-my-zsh"

# zsh-vi-mode: must be set before the plugin is loaded by OMZ
ZVM_VI_INSERT_ESCAPE_BINDKEY=jj
ZVM_SYSTEM_CLIPBOARD_ENABLED=true

# Modules sourced before OMZ:
#   plugins.zsh  — defines plugins=() array consumed by OMZ
#   fzf.zsh      — registers _fzf_file_no_hidden widget referenced in zvm_after_init
#   bindings.zsh — sets ZVM_* cursor/highlight vars and defines zvm_after_init hook
source "${ZDOTDIR}/plugins.zsh"
source "${ZDOTDIR}/fzf.zsh"
source "${ZDOTDIR}/bindings.zsh"

fpath+=${ZSH_CUSTOM:-$ZSH/custom}/plugins/zsh-completions/src
source "$ZSH/oh-my-zsh.sh"

# ============================================================================
# HISTORY
# ============================================================================
HISTSIZE=10000
HISTFILE=~/.zsh_history
SAVEHIST=$HISTSIZE
HISTDUP=erase
setopt appendhistory sharehistory hist_ignore_space hist_ignore_all_dups
setopt hist_save_no_dups hist_ignore_dups hist_find_no_dups

# ============================================================================
# COMPLETION
# ============================================================================
zstyle ':completion:*' matcher-list 'm:{a-z}={A-Za-z}'
zstyle ':completion:*' menu no
zstyle ':fzf-tab:complete:cd:*' fzf-preview \
  'eza --tree --level=1 --icons=always --no-time --no-user --no-permissions $realpath'
zstyle ':fzf-tab:complete:__zoxide_z:*' fzf-preview \
  'eza --tree --level=1 --icons=always --no-time --no-user --no-permissions $realpath'

# ============================================================================
# MODULES (post-OMZ)
# ============================================================================
source "${ZDOTDIR}/aliases.zsh"
source "${ZDOTDIR}/prompt.zsh"
source "${ZDOTDIR}/devs.zsh"
[[ -f "${ZDOTDIR}/secrets.zsh" ]] && source "${ZDOTDIR}/secrets.zsh"
