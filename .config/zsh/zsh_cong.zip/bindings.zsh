# =========================================================
# zsh-vi-mode — must be sourced before OMZ loads the plugin
# =========================================================

# Cursor shape per mode
ZVM_INSERT_MODE_CURSOR=$ZVM_CURSOR_BLINKING_BLOCK
ZVM_NORMAL_MODE_CURSOR=$ZVM_CURSOR_BLOCK
ZVM_VISUAL_MODE_CURSOR=$ZVM_CURSOR_BLOCK
ZVM_OPPEND_MODE_CURSOR=$ZVM_CURSOR_UNDERLINE

# Disable visual-mode line highlight
ZVM_VI_HIGHLIGHT_BACKGROUND=none
ZVM_VI_HIGHLIGHT_FOREGROUND=none
ZVM_VI_HIGHLIGHT_EXTRASTYLE=none

# Edit current command line in $EDITOR (Ctrl+X Ctrl+E)
autoload -Uz edit-command-line
zle -N edit-command-line

# Toggle sudo at the start of the current command line (Alt+S)
_sudo_toggle() {
    if [[ "$BUFFER" == sudo\ * ]]; then
        BUFFER="${BUFFER#sudo }"
    else
        BUFFER="sudo $BUFFER"
    fi
    CURSOR=$#BUFFER
}
zle -N _sudo_toggle

# zsh-vi-mode resets ALL bindings on init, so custom bindings
# must be registered via this hook to survive.
zvm_after_init() {
    # Word navigation
    bindkey '^[[1;5C' forward-word
    bindkey '^[[1;5D' backward-word

    # History navigation
    bindkey '^p'    history-search-backward
    bindkey '^n'    history-search-forward
    bindkey '^[[A'  history-substring-search-up
    bindkey '^[[B'  history-substring-search-down

    # Accept inline autosuggestion
    bindkey '^F' autosuggest-accept

    # Toggle autosuggestions (useful during screen recordings)
    bindkey '^\' autosuggest-toggle

    # Prepend/remove sudo on the current command line (Alt+S)
    bindkey '^[s' _sudo_toggle

    # Open current command line in $EDITOR (Ctrl+X Ctrl+E)
    bindkey '^x^e' edit-command-line
}
