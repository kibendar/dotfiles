# Project and service credentials — keep out of version control

# Spring datasource (fill in when needed)
export SPRING_DATASOURCE_USERNAME=
export SPRING_DATASOURCE_PASSWORD=
export SPRING_DATASOURCE_DRIVER_CLASS_NAME=
export SPRING_DATASOURCE_URL=

# Ajax Systems staging API
export BASE_URL=https://api-e.stage.ajax.systems/api
export BASE_URL_A=https://api-a.stage.ajax.systems/api

export LOGIN_PRO=kononenko.d.a@ajax.systems
export PASSWORD_HASH_PRO=e55f509396651d493ccb4ffefcde42282f5681c6b2f78b96a05ca787c7f2c8ff
export PASSWORD_HASH_PRO_A=3875034e17855bac03a3cc9e107b1d28a9b44313d381c3335588525b4e70b55b
export PRO_ROLE=PRO

export X_COMPANY_TOKEN=jEHh1xXVf7D4gJ7DF3R1jlR
export X_API_KEY=07E7EjngV81X7Lbl1R4TvPd/ZopCBDjy
export X_API_KEY_A=PTW5l2qjL4rI1w6nhT1h9LK/PBkGlUYx
